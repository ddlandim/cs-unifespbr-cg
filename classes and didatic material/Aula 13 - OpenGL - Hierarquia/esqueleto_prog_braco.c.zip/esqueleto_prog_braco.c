// Esqueleto do programa para mexer bra�o rob�tico

#include <GL/glut.h>
#include <stdlib.h>

int angx = 0, angy = 0, angz = 0, shoulder1 = 0, elbow1 = 0;

void desenha_braco(int shoulder, int elbow, int opcao){

  /* transla��o para acertar a rota��o em torno do in�cio do braco */
glPushMatrix();

  //opera��es para controlar a rota��o em torno do ombro

  glPushMatrix();
       glScalef (1.0, 0.5, 1.0);
       glutWireCube (0.2);
  glPopMatrix();

  /* desenha e rotaciona a parte de baixo do bra�o */
  /* origem posicionada no cotovelo */

  glTranslatef(-0.2,0.0,0.0);


  glPushMatrix();
      glScalef (1.0, 0.5, 1.0);
      glutWireCube (0.2);
  glPopMatrix();

glPopMatrix();

/* desenha a m�o */

}

void display(void){
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glClear (GL_COLOR_BUFFER_BIT);

  glPushMatrix();
   /* roda toda a cena */
     glRotatef(angx,1.0,0.0,0.0);
     glRotatef(angy,0.0,1.0,0.0);
     glRotatef(angz,0.0,0.0,1.0);

     // desenha o corpo
     glPushMatrix();
         glScalef(0.6,1.5,0.5);
         glutWireCube(0.4);
     glPopMatrix();

    /* desenha um braco */
    glPushMatrix();
       //translada para acertar o bra�o no corpo
       glTranslatef(-0.22,0.0,0.0);
       desenha_braco(shoulder1,elbow1,1);
    glPopMatrix();


/* desenha outro braco */
     glPushMatrix();

     glPopMatrix();
  glPopMatrix();

  glutSwapBuffers();
}


void keyboard (unsigned char key, int x, int y){
  switch (key) {
/* controla rota��es da cena */
   case 'x':

       break;

   case 'X':

       break;
   

   case 'y':

        break;

   case 'Y':
   
       break;
   


   case 'z':

       break;


   case 'Z':
    
       break;

/* controla rota��es do primeiro braco */
   case 's':
          // adiciona o controle da rota��o positiva do bra�o
          break;
          
   case 'S':
          // adiciona o controle da rota��o negativa do bra�o
          break;
          
   case 'e':
          // adiciona o controle da rota��o positiva da parte inferior do bra�o
          break;
          
   case 'E':
          // adiciona o controle da rota��o negativa da parte inferior do bra�o
          break;
/* sai do programa */
   case 27:
            exit(0);
          break;

  }
}

int main(int argc, char** argv){
  glutInit(&argc, argv);
  glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB);
  glutInitWindowSize (700, 500);
  glutInitWindowPosition (100, 100);
  glutCreateWindow ("Criando bra�os de rob�");
  glutDisplayFunc(display);
  glutKeyboardFunc(keyboard);
  glutMainLoop();
  return 0;
}
