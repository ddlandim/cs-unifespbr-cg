/* Iluminacao.c
 Ilumina��o de um bule com textura. Com o bot�o do meio do mouse � poss�vel escolher o tipo de mapeamento de textura desejada.
*/

#include <windows.h>
#include <stdio.h>
#include <gl/glut.h>

typedef struct BMPImagem
{
    int   width;
    int   height;
    char *data;
}BMPImage;


GLfloat angle=45;
GLfloat fAspect;
GLint eixox=0, eixoy=0, eixoz=0;
GLuint texture_id[1];



//-----------------------------------------------------------------------------
// Name: getBitmapImageData()
// Desc: Simply image loader for 24 bit BMP files.
//-----------------------------------------------------------------------------
void getBitmapImageData( char *pFileName, BMPImage *pImage )
{
    FILE *pFile = NULL;
    unsigned short nNumPlanes;
    unsigned short nNumBPP;
	int i;

    if( (pFile = fopen(pFileName, "rb") ) == NULL )
		printf("ERROR: getBitmapImageData - %s not found.\n", pFileName);

    // Seek forward to width and height info
    fseek( pFile, 18, SEEK_CUR );

    if( (i = fread(&pImage->width, 4, 1, pFile) ) != 1 )
		printf("ERROR: getBitmapImageData - Couldn't read width from %s.\n ", pFileName);

    if( (i = fread(&pImage->height, 4, 1, pFile) ) != 1 )
		printf("ERROR: getBitmapImageData - Couldn't read height from %s.\n ", pFileName);

    if( (fread(&nNumPlanes, 2, 1, pFile) ) != 1 )
		printf("ERROR: getBitmapImageData - Couldn't read plane count from %s.\n", pFileName);

    if( nNumPlanes != 1 )
		printf("ERROR: getBitmapImageData - Plane count from %s.\n ", pFileName);

    if( (i = fread(&nNumBPP, 2, 1, pFile)) != 1 )
		printf( "ERROR: getBitmapImageData - Couldn't read BPP from %s.\n ", pFileName);

    if( nNumBPP != 24 )
		printf("ERROR: getBitmapImageData - BPP from %s.\n ", pFileName);

    // Seek forward to image data
    fseek( pFile, 24, SEEK_CUR );

	// Calculate the image's total size in bytes. Note how we multiply the
	// result of (width * height) by 3. This is becuase a 24 bit color BMP
	// file will give you 3 bytes per pixel.
    int nTotalImagesize = (pImage->width * pImage->height) * 3;

    pImage->data = (char*) malloc( nTotalImagesize );

    if( (i = fread(pImage->data, nTotalImagesize, 1, pFile) ) != 1 )
		printf("ERROR: getBitmapImageData - Couldn't read image data from %s.\n ", pFileName);

    //
	// Finally, rearrange BGR to RGB
	//

	char charTemp;
    for( i = 0; i < nTotalImagesize; i += 3 )
	{
		charTemp = pImage->data[i];
		pImage->data[i] = pImage->data[i+2];
		pImage->data[i+2] = charTemp;
    }
}

//==========================================================================================================================

/* Chamada para fazer o desenho*/
void RenderScene(void)
{
        GLfloat zPlane[] = { 0.0f, 0.0f, 1.0f, 0.0f };

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glColor3f(1.0f, 1.0f, 1.0f);

   /* textura */
	BMPImage imagemTextura;

    getBitmapImageData("surface2.bmp", &imagemTextura);
    //getBitmapImageData("wood.bmp", &imagemTextura);

    glEnable(GL_TEXTURE_2D);

    glGenTextures(1, &texture_id[0]);
    glBindTexture(GL_TEXTURE_2D, texture_id[0]);
    glTexImage2D(GL_TEXTURE_2D, 0, 3, imagemTextura.width,imagemTextura.height, 0, GL_RGB, GL_UNSIGNED_BYTE,imagemTextura.data);


    /* glTextEnv{f i}(GLenum target, GLenum pname, GLfloat param): estabelece os par�metros da textura
           target: Especifica o tipo da textura. Normalmente usa-se GL_TEXTURE_ENV
           pname especifica o nome simb�lico do par�metro da textura.
               Pode ser GL_TEXTURE_ENV_MODE and GL_TEXTURE_ENV_COLOR.
           param: nome da fun��o que ser� usada para a textura. Se pname = GL_TEXTURE_ENV_MODE,
                    ent�o os valores poss�veis aqui s�o: GL_MODULATE, GL_DECAL, GL_BLEND, and GL_REPLACE
           */
   // glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glEnable(GL_TEXTURE_GEN_S);
    glEnable(GL_TEXTURE_GEN_T);



	/* Desenha o teapot s�lido */
	glPushMatrix();
	/*glRotatef(30.0,0.0,1.0,0.0); */
	glRotatef(eixox, 1 ,0 ,0);
    glRotatef(eixoy, 0 ,1 ,0);
    glRotatef(eixoz, 0 ,0 ,1);

	glutSolidTeapot(50.0f);
	//glutSolidSphere(50.0f,30,30);
	//glutSolidTorus(20.0, 50.0, 20, 20);
	glPopMatrix();
    glDisable(GL_TEXTURE_2D);

	glutSwapBuffers();
	}


/* Inicializa��o */
void SetupRC(void)
	{
	/*GLfloat luzAmbiente[4]={0.2,0.2,0.2,1.0};*/
	GLfloat luzAmbiente[4]={0.5,0.5,0.5,1.0};
	GLfloat luzDifusa[4]={0.7,0.7,0.7,1.0};		 /* "cor" */
	GLfloat luzEspecular[4]={1.0, 1.0, 1.0, 1.0}; /* "brilho" */
	GLfloat posicaoLuz[4]={0.0, 50.0, 50.0, 1.0};

    GLfloat objeto_ambiente[4] = {0.5,0.0,0.0,1.0};
    GLfloat objeto_difusa[4] = {1.0,0.0,0.0,1.0};
	/* Capacidade de brilho do material */
	GLfloat especularidade[4]={1.0,1.0,1.0,1.0};
	GLint especMaterial = 30;

 	/* Especifica que a cor de fundo da janela ser� preta */
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

	/* Ativa o uso da luz ambiente */
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, luzAmbiente);

	/* Define os par�metros da luz de n�mero 0 */
	glLightfv(GL_LIGHT0, GL_AMBIENT, luzAmbiente);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, luzDifusa );
	glLightfv(GL_LIGHT0, GL_SPECULAR, luzEspecular );
	glLightfv(GL_LIGHT0, GL_POSITION, posicaoLuz );

    /*glLightf(GL_LIGHT0, GL_CONSTANT_ATTENUATION, 2.0);
    glLightf(GL_LIGHT0, GL_LINEAR_ATTENUATION, 1.0);
    glLightf(GL_LIGHT0, GL_QUADRATIC_ATTENUATION, 0.5);*/

   /* define as propriedades do material */

    glMaterialfv (GL_FRONT_AND_BACK, GL_AMBIENT, objeto_ambiente);
    glMaterialfv (GL_FRONT_AND_BACK, GL_DIFFUSE, objeto_difusa);
   /* Define a reflet�ncia do material */
	glMaterialfv(GL_FRONT,GL_SPECULAR, especularidade);
	/* Define a concentra��o do brilho */
	glMateriali(GL_FRONT,GL_SHININESS,especMaterial);

	/* Habilita a defini��o da cor do material a partir da cor corrente */
	glEnable(GL_COLOR_MATERIAL);
	/* Habilita o uso de ilumina��o*/
	glEnable(GL_LIGHTING);
	/* Habilita a luz de n�mero 0 */
	glEnable(GL_LIGHT0);
	/* Habilita o depth-buffering */
	glEnable(GL_DEPTH_TEST);
	/*glShadeModel(GL_FLAT);*/

	}


/* Fun��o usada para especificar o volume de visualiza��o */
void Viewing(void)
	{
	/* Especifica sistema de coordenadas de proje��o */
	glMatrixMode(GL_PROJECTION);
	/* Inicializa sistema de coordenadas de proje��o */
	glLoadIdentity();

	/* Especifica a proje��o perspectiva */
	gluPerspective(angle,fAspect,0.1,500);

	/* Especifica sistema de coordenadas do modelo */
	glMatrixMode(GL_MODELVIEW);
	/* Inicializa sistema de coordenadas de proje��o */
	glLoadIdentity();

	/* Especifica posi��o do observador e do alvo */
	gluLookAt(0,80,200, 0,0,0, 0,1,0);
	}


/* Chamada pela GLUT quando a janela � redimensionada */
void ChangeSize(GLsizei w, GLsizei h)
	{
	/* Para previnir uma divis�o por zero */
	if ( h == 0 )
		h = 1;

	/* Especifica o tamanho da viewport */
	glViewport(0, 0, w, h);

	/* Calcula a corre��o de aspecto */
	fAspect = (GLfloat)w/(GLfloat)h;

	Viewing();
	}


/* Callback para gerenciar eventos do mouse */
void HandleMouse(int button, int state, int x, int y)
	{
	if (button == GLUT_LEFT_BUTTON)
		if (state == GLUT_DOWN) {
			if (angle >= 10)
				angle -= 5;
		}
	if (button == GLUT_RIGHT_BUTTON)
		if (state == GLUT_DOWN) {
			if (angle <= 130)
				angle += 5;
		}
	Viewing();
	glutPostRedisplay();
	}

void keyboard(unsigned char key, int x, int y){
  switch (key) {
  case 'x':
    eixox = (eixox + 5) % 360;
    glutPostRedisplay();
    break;
  case 'y':
    eixoy = (eixoy + 5) % 360;
    glutPostRedisplay();
    break;
  case 'z':
    eixoz = (eixoz + 5) % 360;
    glutPostRedisplay();
    break;
  case 'X':
    eixox = (eixox - 5) % 360;
    glutPostRedisplay();
    break;
  case 'Y':
    eixoy = (eixoy - 5) % 360;
    glutPostRedisplay();
    break;
  case 'Z':
    eixoz = (eixoz - 5) % 360;
    glutPostRedisplay();
    break;
  }
}
///////////////////////////////////////////////////////////////////////////////
// Atualiza value de acordo com a op��o selecionada no Menu
void ProcessMenu(int value)
    {
    // Plano de Proje��o
    GLfloat Plano[] = { 1.0f, 0.0f, 0.0f, 0.0f };

    switch(value)
        {
        case 1:
            // Object Linear
            glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
            glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
            glTexGenfv(GL_S, GL_OBJECT_PLANE, Plano);
            glTexGenfv(GL_T, GL_OBJECT_PLANE, Plano);
            break;

		case 2:
            // Eye Linear
            glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
            glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
            glTexGenfv(GL_S, GL_EYE_PLANE, Plano);
            glTexGenfv(GL_T, GL_EYE_PLANE, Plano);
			break;

		case 3:
        default:
            // Sphere Map
            glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
            glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
            break;
		}

    glutPostRedisplay();    // Redisplay
    }


/* **********************************************************************
  void main ( int argc, char** argv )


 ********************************************************************** */
int main ( int argc, char** argv )  {
	glutInit( &argc, argv );
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(400,350);
	glutCreateWindow("Visualizacao 3D - Textura e iluminacao");
	glutDisplayFunc(RenderScene);
	glutReshapeFunc(ChangeSize);
	glutMouseFunc(HandleMouse);
    glutKeyboardFunc(keyboard);
	SetupRC();

	// Cria um Menu
	glutCreateMenu(ProcessMenu);
    glutAddMenuEntry("Object Linear",1);
	glutAddMenuEntry("Eye Linear",2);
	glutAddMenuEntry("Sphere Map",3);
	glutAttachMenu(GLUT_MIDDLE_BUTTON);

	glutMainLoop();
	return 0;
}
