#include <stdio.h>
#include <stdlib.h>
#include <GL/glut.h>

typedef struct BMPImagem
{
    int   width;
    int   height;
    char *data;
}BMPImage;

float xrot;
float yrot;
float zrot;
float ratio;

GLuint texture_id; /* identificador da textura */

//-----------------------------------------------------------------------------
// Name: getBitmapImageData()
// Desc: Simply image loader for 24 bit BMP files.
//-----------------------------------------------------------------------------
void getBitmapImageData( char *pFileName, BMPImage *pImage )
{
    FILE *pFile = NULL;
    unsigned short nNumPlanes;
    unsigned short nNumBPP;
	int i;

    if( (pFile = fopen(pFileName, "rb") ) == NULL )
		printf("ERROR: getBitmapImageData - %s not found.\n", pFileName);

    // Seek forward to width and height info
    fseek( pFile, 18, SEEK_CUR );

    if( (i = fread(&pImage->width, 4, 1, pFile) ) != 1 )
		printf("ERROR: getBitmapImageData - Couldn't read width from %s.\n ", pFileName);

    if( (i = fread(&pImage->height, 4, 1, pFile) ) != 1 )
		printf("ERROR: getBitmapImageData - Couldn't read height from %s.\n ", pFileName);

    if( (fread(&nNumPlanes, 2, 1, pFile) ) != 1 )
		printf("ERROR: getBitmapImageData - Couldn't read plane count from %s.\n", pFileName);

    if( nNumPlanes != 1 )
		printf("ERROR: getBitmapImageData - Plane count from %s.\n ", pFileName);

    if( (i = fread(&nNumBPP, 2, 1, pFile)) != 1 )
		printf( "ERROR: getBitmapImageData - Couldn't read BPP from %s.\n ", pFileName);

    if( nNumBPP != 24 )
		printf("ERROR: getBitmapImageData - BPP from %s.\n ", pFileName);

    // Seek forward to image data
    fseek( pFile, 24, SEEK_CUR );

	// Calculate the image's total size in bytes. Note how we multiply the
	// result of (width * height) by 3. This is becuase a 24 bit color BMP
	// file will give you 3 bytes per pixel.
    int nTotalImagesize = (pImage->width * pImage->height) * 3;

    pImage->data = (char*) malloc( nTotalImagesize );

    if( (i = fread(pImage->data, nTotalImagesize, 1, pFile) ) != 1 )
		printf("ERROR: getBitmapImageData - Couldn't read image data from %s.\n ", pFileName);

    //
	// Finally, rearrange BGR to RGB
	//

	char charTemp;
    for( i = 0; i < nTotalImagesize; i += 3 )
	{
		charTemp = pImage->data[i];
		pImage->data[i] = pImage->data[i+2];
		pImage->data[i+2] = charTemp;
    }
}


/*Fun��o para Carregar uma imagem .BMP */
void CarregaTextura(char* Filename)
{

    BMPImage textura;

    getBitmapImageData( Filename, &textura);

    // Defina os par�metros da textura

}


/* **********************************************************************
  void init(void)
		Inicializa os par�metros globais de OpenGL

 ********************************************************************** */
void init(void) {
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);			/* Black Background */
	glEnable(GL_DEPTH_TEST);

}

/* **********************************************************************
  void reshape( int w, int h )
		trata o redimensionamento da janela OpenGL

 ********************************************************************** */
void reshape( int w, int h )
{
	/* Prevent a divide by zero, when window is too short
	 (you cant make a window of zero width). */
	if(h == 0)
		h = 1;

	/* Set the viewport to be the entire window */
            glViewport(0, 0, w, h);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

}

/* **********************************************************************
  void display( void )


 ********************************************************************** */
void display( void )
{
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glLoadIdentity ( );
	glPushMatrix();
	glRotatef ( xrot, 1.0, 0.0, 0.0 );
	glRotatef ( yrot, 0.0, 1.0, 0.0 );
	glRotatef ( zrot, 0.0, 0.0, 1.0 );

	/* define qual das texturas usar */
	glBindTexture ( GL_TEXTURE_2D, texture_id );

	glBegin ( GL_QUADS );
		/* Front Face */
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-0.3f, -0.3f,  0.3f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f( 0.3f, -0.3f,  0.3f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f( 0.3f,  0.3f,  0.3f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-0.3f,  0.3f,  0.3f);
		/* Back Face */
		glTexCoord2f(1.0f, 0.0f); glVertex3f(-0.3f, -0.3f, -0.3f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(-0.3f,  0.3f, -0.3f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f( 0.3f,  0.3f, -0.3f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f( 0.3f, -0.3f, -0.3f);
		/* Top Face */
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-0.3f,  0.3f, -0.3f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-0.3f,  0.3f,  0.3f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f( 0.3f,  0.3f,  0.3f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f( 0.3f,  0.3f, -0.3f);
		/* Bottom Face */
		glTexCoord2f(1.0f, 1.0f); glVertex3f(-0.3f, -0.3f, -0.3f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f( 0.3f, -0.3f, -0.3f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f( 0.3f, -0.3f,  0.3f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(-0.3f, -0.3f,  0.3f);
		/* Right face */
		glTexCoord2f(1.0f, 0.0f); glVertex3f( 0.3f, -0.3f, -0.3f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f( 0.3f,  0.3f, -0.3f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f( 0.3f,  0.3f,  0.3f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f( 0.3f, -0.3f,  0.3f);
		/* Left Face */
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-0.3f, -0.3f, -0.3f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(-0.3f, -0.3f,  0.3f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(-0.3f,  0.3f,  0.3f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-0.3f,  0.3f, -0.3f);
	glEnd();

	glPopMatrix();

	glutSwapBuffers();
}



/* **********************************************************************
  void keyboard ( unsigned char key, int x, int y )

 ********************************************************************** */
void keyboard ( unsigned char key, int x, int y )
{
	switch ( key )
	{
	case 'x':
                   xrot+= 5;
                   glutPostRedisplay();
             break;
             case 'y':
                    yrot+= 5;
                    glutPostRedisplay();
             break;
             case 'z':
                  zrot+= 5;
                  glutPostRedisplay();
            break;
            case 'X':
                   xrot-= 5;
                   glutPostRedisplay();
            break;
            case 'Y':
                     yrot-= 5;
                    glutPostRedisplay();
             break;
             case 'Z':
                      zrot-= 5;
                      glutPostRedisplay();
              break;
              case 27:        /* When Escape Is Pressed... */
                      exit ( 0 );   /* Exit The Program */
               break;        /* Ready For Next Case */
  }
}

/* ********************************************************************** */
/*  void arrow_keys ( int a_keys, int x, int y )   */


/* ********************************************************************** */
void arrow_keys ( int a_keys, int x, int y )
{
	switch ( a_keys )
	{
		case GLUT_KEY_UP:     /* When Up Arrow Is Pressed... */
			glutFullScreen ( ); /* Go Into Full Screen Mode */
			break;
	    case GLUT_KEY_DOWN:               /* When Down Arrow Is Pressed... */
                                    glutPositionWindow (50,50);
			glutReshapeWindow ( 700, 700 );
			break;
		default:
			break;
	}
}

/* **********************************************************************
 main ( int argc, char** argv )


 ********************************************************************** */
int main ( int argc, char** argv )
{
	glutInit            ( &argc, argv );
	glutInitDisplayMode ( GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA );
	glutInitWindowPosition (50,50);
	glutInitWindowSize  ( 700, 500 );
	glutCreateWindow    ( "Computacao Grafica - Teste com Texturas." );

	init ();
    CarregaTextura("tunnelTexture.bmp");

	glutDisplayFunc ( display );
	glutReshapeFunc ( reshape );
	glutKeyboardFunc ( keyboard );
	glutSpecialFunc ( arrow_keys );
	glutMainLoop ( );
	return 0;
}
